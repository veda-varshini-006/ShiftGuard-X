NB127: independent Chimp-family screening and official upstream source provenance. NOT an official ALP/Chimp standalone benchmark. Only verified roundtrips are usable.
