NB126: FPZIP exactness diagnostics. FPZIP streams failing 64-bit reconstruction must not be considered lossless. ALP and Chimp standalone benchmarking remains outstanding.
