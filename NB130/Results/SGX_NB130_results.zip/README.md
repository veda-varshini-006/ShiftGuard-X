ShiftGuard-X NB130 originality gate. All entropy examples and overhead sensitivity are SYNTHETIC/HYPOTHETICAL, not codec benchmark gains. Prior-art matrix is preliminary. Novelty unestablished.
