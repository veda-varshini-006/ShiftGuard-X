NB122 paid-probing diagnostic. These costs derive from actual compressed block bytes; online policies use a precomputed forensic trace, never future outcomes to choose actions. Not a novel algorithm.
