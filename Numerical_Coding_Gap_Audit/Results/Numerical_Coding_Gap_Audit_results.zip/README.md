NB123 is a bit-exact reversible representation diagnostic, NOT an original codec or a benchmark against ALP/Elf*. Values are original float64 for TLC and float64 parsed from UCI decimal CSV for Wine.
