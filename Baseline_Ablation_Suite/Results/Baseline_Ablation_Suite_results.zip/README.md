NB121: measured zlib XOR residual baselines and vendor ablations; full IEEE-754 word roundtrips. Target-column bundles, NOT original Parquet sizes. No novelty claim.
