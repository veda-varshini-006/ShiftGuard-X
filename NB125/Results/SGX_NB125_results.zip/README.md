NB125 compares standalone official Python bindings of Pcodec and FPZIP against zstd/lzma, on identical float64 column streams. It does NOT measure ALP/Chimp official streams or whole Parquet files.
