# NB118 — Natural arithmetic-path discovery

Real sources: New York City TLC official Parquet, 2024 Yellow Jan/Feb and Green Feb.
https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

**Not a novel compressor.** Experimental gate: True
Source completeness: COMPLETE

## Outcomes
- yellow_2024_01: 5288 independent recorded target matches from alternatives only / 125000 qualified rows (4.2304%). 95% Wilson CI: [0.041202165, 0.043433966].
- yellow_2024_02: 5984 independent recorded target matches from alternatives only / 125000 qualified rows (4.7872%). 95% Wilson CI: [0.046702295, 0.049069494].
- green_2024_02: 1612 independent recorded target matches from alternatives only / 53577 qualified rows (3.0088%). 95% Wilson CI: [0.028674387, 0.031568068].

## Limitations
- This is a prevalence experiment, not an encoder/decoder or whole-file compression benchmark.
- Addition-order differences are real IEEE-754 effects but do not prove the upstream vendor evaluated a specific expression.
- TLC sources may omit fees, have corrections, include vendor processing, or contain data anomalies; see zero-imputation assumptions.
- First 125k rows per month are deterministic but not random; Wilson intervals assume independent sampled rows and are descriptive only, not population inference. Confirm on independent larger random samples.
- Source definition must not be changed in response to the held-out February outcomes.
- Multiple-predictor compression, dependency coding and exception coding have substantial prior art (ALP, Corra, FPC, Virtual).
- Even a passed prevalence gate would NOT establish originality or compression advantage.

## Next research action
If any source is unavailable: resolve access and rerun identical locked experiment.
If the gate fails: stop arithmetic-path coding for this data/domain; reassess the problem statement.
If the gate passes: mathematically differentiate from prior-art multi-predictor coding before building a codec.
