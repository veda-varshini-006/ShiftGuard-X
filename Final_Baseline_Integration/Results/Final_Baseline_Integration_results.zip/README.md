NB128 final integration audit: pcodec standalone, zstd, lzma measured on identical float64 streams. ALP/Chimp git build tests are not compression-size evidence. No novelty established.
