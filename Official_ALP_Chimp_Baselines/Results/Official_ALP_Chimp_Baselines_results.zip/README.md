Official DuckDB forced ALP/Chimp availability and exactness; database bytes NOT directly comparable to standalone zstd. No new algorithm established.
