N119 reconstructed information-cost feasibility audit. Only NB118 prevalence is measured; all savings sensitivity values are hypothetical. No codec benchmark or novelty established.
